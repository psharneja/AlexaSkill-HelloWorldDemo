const Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback){
  let alexa = Alexa.handler(event, context);
  alexa.registerHandlers(handlers);
  alexa.execute();
};


let handlers = {
  'LaunchRequest' : function() {
    this.emit(':tell', 'Hello World');
  },
  'GreetingIntent': function() {
    this.emit(':tell', 'Hey Everyone! Alexa\'s here, Your Assistant for the day.');
  },
  'Simar': function() {
    this.emit(':tell','Hey! Good Afternoon Seemur.');
  }
};


//wiprogafa.signin.aws.amazon.com
